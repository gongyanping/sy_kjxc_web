import patrolPoint from './patrolPoint'
import clockinRecord from './clockinRecord'

export {
  patrolPoint,
  clockinRecord
}
