<template>
  <div class="nodata" >暂无数据</div>
</template>

<style lang="less">
.nodata{
  width: 100%;
  text-align: center;
  color: #ccc;
  font-size: 18px;
  margin-top: 30px;
}
</style>
